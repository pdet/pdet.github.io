#include <catch.hpp>
#include "tester.hpp"
#include "full_scan.hpp"

TEST_CASE("Test FullScan", "[FullScan]" )
{
    Tester::test(FullScan::ID);
}

#include <catch.hpp>
#include "tester.hpp"
#include "cracking_kd_tree.hpp"

TEST_CASE("Test Cracking KDTree", "[CrackingKDTree]" )
{
    Tester::test(CrackingKDTree::ID);
}

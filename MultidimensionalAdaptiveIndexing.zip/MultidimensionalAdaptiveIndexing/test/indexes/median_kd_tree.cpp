#include <catch.hpp>
#include "tester.hpp"
#include "median_kd_tree.hpp"

TEST_CASE("Test Median KDTree", "[MedianKDTree]")
{
    Tester::test(MedianKDTree::ID);
}

#include <cstdio>
#include <chrono>
#include <math.h>
#include <generators/uniform_generator.hpp>
#include <candidate_list.hpp>
#include <bitvector.hpp>
#include <bitvector.h>

using namespace std;
using namespace chrono;

//! Full_Scan with candidate list new
void fs_cln(Table &table, Workload &workload, size_t dimensions, double &sum) {
    for (size_t w_idx = 0; w_idx < workload.query_count(); w_idx++) {
        CandidateList cl;
        //! Create cl based on first column
        auto column = table.columns[0]->data;
        auto low = workload.queries[w_idx].predicates[0].low;
        auto high = workload.queries[w_idx].predicates[0].high;
        for (size_t c_idx = 0; c_idx < table.row_count(); c_idx++) {
            if (column[c_idx] >= low && column[c_idx] <= high) {
                cl.push_back(c_idx);
            }
        }
        for (size_t d_idx = 1; d_idx < dimensions; d_idx++) {
            CandidateList new_cl(cl.size);
            column = table.columns[d_idx]->data;
            low = workload.queries[w_idx].predicates[d_idx].low;
            high = workload.queries[w_idx].predicates[d_idx].high;
            for (size_t cl_idx = 0; cl_idx < cl.size; cl_idx++) {
                if (column[cl.get(cl_idx)] >= low && column[cl.get(cl_idx)] <= high) {
                    new_cl.push_back(cl.get(cl_idx));
                }
            }
            //! Move new_cl -> cl
            cl.initialize(new_cl);
        }
        //! Iterate through final cl to get sum
        column = table.columns[0]->data;
        for (size_t cl_idx = 0; cl_idx < cl.size; cl_idx++) {
            sum += column[cl.get(cl_idx)];
        }
    }
}

//! Full_Scan with candidate list replace
void fs_cls(Table &table, Workload &workload, size_t dimensions, double &sum) {
    for (size_t w_idx = 0; w_idx < workload.query_count(); w_idx++) {
        CandidateList cl;
        //! Create cl based on first column
        auto column = table.columns[0]->data;
        auto low = workload.queries[w_idx].predicates[0].low;
        auto high = workload.queries[w_idx].predicates[0].high;
        for (size_t c_idx = 0; c_idx < table.row_count(); c_idx++) {
            if (column[c_idx] >= low && column[c_idx] <= high) {
                cl.push_back(c_idx);
            }
        }
        for (size_t d_idx = 1; d_idx < dimensions; d_idx++) {
            column = table.columns[d_idx]->data;
            low = workload.queries[w_idx].predicates[d_idx].low;
            high = workload.queries[w_idx].predicates[d_idx].high;

            auto qualifying_index = 0;
            for (size_t cl_idx = 0; cl_idx < cl.size; cl_idx++) {
                if (column[cl.get(cl_idx)] >= low && column[cl.get(cl_idx)] <= high) {
                    cl.data[qualifying_index] = cl.get(cl_idx);
                    qualifying_index++;
                }
            }
            cl.size = qualifying_index;
        }
        //! Iterate through final cl to get sum
        column = table.columns[0]->data;
        for (size_t cl_idx = 0; cl_idx < cl.size; cl_idx++) {
            sum += column[cl.get(cl_idx)];
        }
    }
}

//! Full_Scan with bitvector + get
void fs_bvg(Table &table, Workload &workload, size_t dimensions, double &sum) {
    for (size_t w_idx = 0; w_idx < workload.query_count(); w_idx++) {
//        auto start_timer = system_clock::now();
        BitVector bv = BitVector(table.row_count());
//        auto end_timer = system_clock::now();
//        auto init_time = duration<double>(end_timer - start_timer).count();
//        cout << "Bit Vector (init) with get : " << init_time << endl;
        //! Create cl based on first column
        auto column = table.columns[0]->data;
        auto low = workload.queries[w_idx].predicates[0].low;
        auto high = workload.queries[w_idx].predicates[0].high;
        for (size_t c_idx = 0; c_idx < table.row_count(); c_idx++) {
            if (column[c_idx] >= low && column[c_idx] <= high) {
                bv.set(c_idx);
            }
        }
        for (size_t d_idx = 1; d_idx < dimensions; d_idx++) {
            column = table.columns[d_idx]->data;
            low = workload.queries[w_idx].predicates[d_idx].low;
            high = workload.queries[w_idx].predicates[d_idx].high;
            for (size_t c_idx = 0; c_idx < table.row_count(); c_idx++) {
                if (bv.get(c_idx) && !(column[c_idx] >= low && column[c_idx] <= high)) {
                    bv.unset(c_idx);
                }
            }
        }
        //! Iterate through final bv to get sum
        column = table.columns[0]->data;
        for (size_t c_idx = 0; c_idx < table.row_count(); c_idx++) {
            if (bv.get(c_idx)) {
                sum += column[c_idx];
            }
        }
    }
}

//! Full_Scan with bitvector + AND
void fs_bva(Table &table, Workload &workload, size_t dimensions, double &sum) {
    for (size_t w_idx = 0; w_idx < workload.query_count(); w_idx++) {
        BitVector bv = BitVector(table.row_count());
        BitVector bv_aux = BitVector(table.row_count());

        //! Create cl based on first column
        auto column = table.columns[0]->data;
        auto low = workload.queries[w_idx].predicates[0].low;
        auto high = workload.queries[w_idx].predicates[0].high;
        for (size_t c_idx = 0; c_idx < table.row_count(); c_idx++) {
            if (column[c_idx] >= low && column[c_idx] <= high) {
                bv.set(c_idx);
            }
        }
        for (size_t d_idx = 1; d_idx < dimensions; d_idx++) {
            column = table.columns[d_idx]->data;
            low = workload.queries[w_idx].predicates[d_idx].low;
            high = workload.queries[w_idx].predicates[d_idx].high;
            for (size_t c_idx = 0; c_idx < table.row_count(); c_idx++) {
                if(column[c_idx] >= low && column[c_idx] <= high){
                    bv_aux.set(c_idx);
                }
            }
            bv.bitwise_and(bv_aux);
        }
        //! Iterate through final bv to get sum
        column = table.columns[0]->data;
        for (size_t c_idx = 0; c_idx < table.row_count(); c_idx++) {
            if (bv.get(c_idx)) {
                sum += column[c_idx];
            }
        }
    }
}

//! Full_Scan with bitvector + get + no ifs
void fs_bvgp(Table &table, Workload &workload, size_t dimensions, double &sum) {
    for (size_t w_idx = 0; w_idx < workload.query_count(); w_idx++) {
//        auto start_timer = system_clock::now();
        BitVector bv = BitVector(table.row_count());
//        auto end_timer = system_clock::now();
//        auto init_time = duration<double>(end_timer - start_timer).count();
//        cout << "Bit Vector (init) with get : " << init_time << endl;
        //! Create cl based on first column
        auto column = table.columns[0]->data;
        auto low = workload.queries[w_idx].predicates[0].low;
        auto high = workload.queries[w_idx].predicates[0].high;
        for (size_t c_idx = 0; c_idx < table.row_count(); c_idx++) {
            bv.set(c_idx, column[c_idx] >= low && column[c_idx] <= high);
        }
        for (size_t d_idx = 1; d_idx < dimensions; d_idx++) {
            column = table.columns[d_idx]->data;
            low = workload.queries[w_idx].predicates[d_idx].low;
            high = workload.queries[w_idx].predicates[d_idx].high;
            for (size_t c_idx = 0; c_idx < table.row_count(); c_idx++) {
                bv.set(c_idx, bv.get(c_idx) && !(column[c_idx] >= low && column[c_idx] <= high));
            }
        }
        //! Iterate through final bv to get sum
        column = table.columns[0]->data;
        for (size_t c_idx = 0; c_idx < table.row_count(); c_idx++) {
            if (bv.get(c_idx)) {
                sum += column[c_idx];
            }
        }
    }
}


int main() {
    size_t n_of_rows = 10e7;
    size_t dimensions = 2;
    //! Note that selectivity is per query, not per column
    float selectivity = 0.001; //! 1 = 100%
    size_t number_of_queries = 10;
    string DATA_FILE = "/tmp/data";
    string QUERY_FILE = "/tmp/query";
    double cln_sum = 0;
    //! Generate Table + Queries
    std::cout << "Generating Data\n";
    auto generator = UniformGenerator(n_of_rows, dimensions, selectivity, number_of_queries);
    generator.generate(DATA_FILE, QUERY_FILE);
    auto table = Table::read_file(DATA_FILE);
    auto workload = Workload::read_file(QUERY_FILE);

    std::cout << "Starting benchmark\n";

    auto start_timer = system_clock::now();
    fs_cln(*table, workload, dimensions, cln_sum);
    auto end_timer = system_clock::now();
    auto scan_time = duration<double>(end_timer - start_timer).count() / number_of_queries;
    cout << cln_sum << endl;
    cout << "Candidate List with new : " << scan_time << endl;

    double cls_sum = 0;
    start_timer = system_clock::now();
    fs_cls(*table, workload, dimensions, cls_sum);
    end_timer = system_clock::now();
    scan_time = duration<double>(end_timer - start_timer).count() / number_of_queries;
    cout << cls_sum << endl;
    cout << "Candidate List with swap : " << scan_time << endl;

    double bvg_sum = 0;
    start_timer = system_clock::now();
    fs_bvg(*table, workload, dimensions, bvg_sum);
    end_timer = system_clock::now();
    scan_time = duration<double>(end_timer - start_timer).count() / number_of_queries;
    cout << bvg_sum << endl;
    cout << "Bit Vector with get : " << scan_time << endl;

    double bvn_sum = 0;
    start_timer = system_clock::now();
    fs_bva(*table, workload, dimensions, bvn_sum);
    end_timer = system_clock::now();
    scan_time = duration<double>(end_timer - start_timer).count() / number_of_queries;
    cout << bvn_sum << endl;
    cout << "Bit Vector with new : " << scan_time << endl;
    
    double bvgp_sum = 0;
    start_timer = system_clock::now();
    fs_bvgp(*table, workload, dimensions, bvgp_sum);
    end_timer = system_clock::now();
    scan_time = duration<double>(end_timer - start_timer).count() / number_of_queries;
    cout << bvgp_sum << endl;
    cout << "Bit Vector with get and no ifs: " << scan_time << endl;
}

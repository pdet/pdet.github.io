#include <catch.hpp>
#include "tester.hpp"
#include "average_kd_tree.hpp"

TEST_CASE("Test Average KDTree ", "[AverageKDTree]" )
{
    Tester::test(AverageKDTree::ID);
}

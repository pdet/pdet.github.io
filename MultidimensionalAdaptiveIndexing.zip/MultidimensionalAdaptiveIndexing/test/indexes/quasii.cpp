#include <catch.hpp>
#include "tester.hpp"
#include "quasii.hpp"

TEST_CASE("Test Quasii", "[Quasii]")
{
    Tester::test(Quasii::ID);
}

#include <catch.hpp>
#include "tester.hpp"
#include "full_scan_candidate_list.hpp"

TEST_CASE("Test FullScan Condidate List", "[FullScanCandidateList]" )
{
    Tester::test(FullScanCandidateList::ID);
}
